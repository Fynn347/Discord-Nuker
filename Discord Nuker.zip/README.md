Der Bot in diesem Skript führt drastische Änderungen auf einem Discord-Server durch. Hier ist eine kurze Zusammenfassung der Schritte, die du unternehmen musst:

Was du tun musst:
Bot-Token und Serverinformationen eingeben:

Starte das Skript und gib den Bot-Token sowie die gewünschten Einstellungen ein:
Neuer Servername.
Neuer Kanalname.
Spam-Nachricht, die der Bot in die Kanäle senden wird.
Rollenname(n) (durch Komma getrennt).
Bestätigung anfordern:

Das Skript fragt dich, ob du sicher bist, dass du fortfahren möchtest. Bestätige mit "j", um fortzufahren, oder mit "n", um den Vorgang abzubrechen.
Bot starten:

Sobald der Bot erfolgreich eingeloggt ist, gib den Befehl !n in den Discord-Chat ein, um den "Nuke"-Prozess zu starten.
Was der Bot tut:
Servername ändern: Der Bot ändert den Servernamen in den angegebenen neuen Namen.
Alle Rollen löschen: Der Bot löscht alle Rollen außer der Standardrolle @everyone.
Alle Kanäle löschen: Der Bot löscht alle bestehenden Kanäle auf dem Server.
Neue Rollen erstellen: Der Bot erstellt 20 neue Rollen mit allen Berechtigungen.
Rollen zuweisen: Alle Mitglieder des Servers erhalten alle neuen Rollen.
Neue Kanäle erstellen: 40 neue Kanäle werden erstellt.
Nachrichten senden: Der Bot sendet die angegebene Nachricht in allen neu erstellten Kanälen 20-mal.
Vorsicht:
Vollständige Veränderung des Servers: Alle Kanäle und Rollen werden gelöscht und ersetzt. Stelle sicher, dass du den Bot in einem Server mit den entsprechenden Berechtigungen und im richtigen Kontext verwendest.